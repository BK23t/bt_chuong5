from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# ==========================================
# CÁC HÀM XỬ LÝ HỖ TRỢ
# ==========================================

# Bài 1
def parse_number_b1(val_str):
    if not val_str:
        return None
    val_str = val_str.strip().replace(',', '.')
    try:
        return float(val_str)
    except ValueError:
        return None

def format_number_b1(val):
    if val.is_integer():
        return str(int(val))
    return str(val)

# Bài 2
def validate_score_b2(val_str, field_name):
    if not val_str or val_str.strip() == '':
        return None, f"Lỗi ở {field_name}: Vui lòng nhập một số."
    val_str = val_str.strip().replace(',', '.')
    try:
        score = float(val_str)
    except ValueError:
        return None, f"Lỗi ở {field_name}: Vui lòng nhập một số."
    if score < 0 or score > 10:
        return None, f"Lỗi ở {field_name}: Điểm phải từ 0 đến 10."
    return score, None

def get_grade_letter_b2(final_score, ck_score):
    if ck_score < 3.0:
        return "F (điểm liệt)"
    if final_score >= 8.5: return "A"
    elif final_score >= 7.0: return "B"
    elif final_score >= 5.5: return "C"
    elif final_score >= 4.0: return "D"
    else: return "F"

# ==========================================
# ROUTES / ĐƯỜNG DẪN
# ==========================================

@app.route('/')
def home():
    return redirect(url_for('bai1'))

# --- BÀI 1: MÁY TÍNH CƠ BẢN ---
@app.route('/bai1', methods=['GET', 'POST'])
def bai1():
    a_str, b_str, op = '', '', '+'
    error_a, error_b, error_op, result_str = None, None, None, None

    if request.method == 'POST':
        a_str = request.form.get('a', '')
        b_str = request.form.get('b', '')
        op = request.form.get('op', '')

        num_a = parse_number_b1(a_str)
        num_b = parse_number_b1(b_str)

        if num_a is None: error_a = "Vui lòng nhập một số."
        if num_b is None: error_b = "Vui lòng nhập một số."
        if op not in ['+', '-', '*', '/']: error_op = "Phép toán không hợp lệ."
        if num_b == 0 and op == '/': error_b = "Không thể chia cho 0."

        if not error_a and not error_b and not error_op:
            if op == '+': res = num_a + num_b
            elif op == '-': res = num_a - num_b
            elif op == '*': res = num_a * num_b
            elif op == '/': res = num_a / num_b
            result_str = f"{format_number_b1(num_a)} {op} {format_number_b1(num_b)} = {format_number_b1(res)}"

    return render_template('bai1.html', active_page=1, a=a_str, b=b_str, op=op, error_a=error_a, error_b=error_b, error_op=error_op, result_str=result_str)

# --- BÀI 2: TÍNH ĐIỂM HỌC PHẦN ---
@app.route('/bai2', methods=['GET', 'POST'])
def bai2():
    cc_str, gk_str, ck_str = '', '', ''
    error_cc, error_gk, error_ck, result_str = None, None, None, None

    if request.method == 'POST':
        cc_str = request.form.get('cc', '')
        gk_str = request.form.get('gk', '')
        ck_str = request.form.get('ck', '')

        num_cc, error_cc = validate_score_b2(cc_str, "CC")
        num_gk, error_gk = validate_score_b2(gk_str, "GK")
        num_ck, error_ck = validate_score_b2(ck_str, "CK")

        if error_cc is None and error_gk is None and error_ck is None:
            raw_score = num_cc * 0.1 + num_gk * 0.3 + num_ck * 0.6
            final_score = round(raw_score, 1)
            letter = get_grade_letter_b2(final_score, num_ck)
            result_str = f"{final_score} - {letter}"

    return render_template('bai2.html', active_page=2, cc=cc_str, gk=gk_str, ck=ck_str, error_cc=error_cc, error_gk=error_gk, error_ck=error_ck, result_str=result_str)

# --- BÀI 3: TÍNH CHỈ SỐ BMI ---
@app.route('/bai3', methods=['GET', 'POST'])
def bai3():
    cao_str, nang_str = '', ''
    error_cao, error_nang = None, None
    bmi_res, status_res, color_res, range_weight = None, None, None, None

    if request.method == 'POST':
        cao_str = request.form.get('cao', '')
        nang_str = request.form.get('nang', '')

        # Kiểm tra Chiều cao (50 đến 250 cm)
        val_cao = None
        if not cao_str or cao_str.strip() == '':
            error_cao = "Lỗi ở chiều cao: Vui lòng nhập một số."
        else:
            try:
                val_cao = float(cao_str.strip().replace(',', '.'))
                if val_cao < 50:
                    error_cao = "Giá trị phải từ 50 đến 250. (nhập mét thay vì cm)"
                elif val_cao > 250:
                    error_cao = "Giá trị phải từ 50 đến 250."
            except ValueError:
                error_cao = "Lỗi ở chiều cao: Vui lòng nhập một số."

        # Kiểm tra Cân nặng (10 đến 300 kg)
        val_nang = None
        if not nang_str or nang_str.strip() == '':
            error_nang = "Lỗi ở cân nặng: Vui lòng nhập một số."
        else:
            try:
                val_nang = float(nang_str.strip().replace(',', '.'))
                if val_nang < 10 or val_nang > 300:
                    error_nang = "Lỗi ở cân nặng: Giá trị phải từ 10 đến 300."
            except ValueError:
                error_nang = "Lỗi ở cân nặng: Vui lòng nhập một số."

        # Tính toán nếu dữ liệu hợp lệ
        if error_cao is None and error_nang is None:
            h_m = val_cao / 100.0  # Đổi cm sang m
            bmi = round(val_nang / (h_m ** 2), 1)

            # Phân loại theo chuẩn người châu Á & gán màu
            if bmi < 18.5:
                status = "Thiếu cân"
                color = "orange"  # Màu vàng/cam
            elif bmi < 23.0:
                status = "Bình thường"
                color = "green"   # Màu xanh
            elif bmi < 25.0:
                status = "Thừa cân"
                color = "orange"  # Màu vàng/cam
            else:
                status = "Béo phì"
                color = "red"     # Màu đỏ

            # Tính khoảng cân nặng nên có (ứng với BMI 18.5 - 22.9)
            w_min = round(18.5 * (h_m ** 2), 1)
            w_max = round(22.9 * (h_m ** 2), 1)

            bmi_res = bmi
            status_res = status
            color_res = color
            range_weight = f"nên có {w_min} – {w_max} kg"

    return render_template(
        'bai3.html', active_page=3,
        cao=cao_str, nang=nang_str,
        error_cao=error_cao, error_nang=error_nang,
        bmi=bmi_res, status=status_res, color=color_res, range_weight=range_weight
    )

if __name__ == '__main__':
    app.run(debug=True)